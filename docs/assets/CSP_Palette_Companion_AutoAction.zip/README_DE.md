# CSP Palette Companion – Auto Action

Die fertige Action heißt **Sichtbare Ebenen kopieren**.

## Am einfachsten: importieren

1. In Clip Studio Paint die Palette **Auto-Action** öffnen.
2. Das Palettenmenü öffnen.
3. **Set importieren...** wählen.
4. `CSP_Palette_Companion.laf` auswählen.
5. Die Action **Sichtbare Ebenen kopieren** starten.

Die Action erstellt kurz eine zusammengeführte Kopie aller sichtbaren Ebenen, kopiert sie in die Zwischenablage und löscht die temporäre Ebene anschließend wieder.

![Fertige Action](07_action_fertig.png)

![Set exportieren oder importieren](08_set_exportieren_oder_importieren.png)

## Falls die Action manuell nachgebaut werden soll

1. Ein Dokument mit mehreren sinnvoll benannten Ebenen öffnen.

   ![Ausgangslage mit Ebenen](01_ausgangslage_ebenen.png)

2. Die Palette **Auto-Action** einblenden und eine neue Action anlegen.

   ![Auto-Action-Palette](02_auto_action_palette.png)

3. Die Aufnahme starten.

   ![Aufnahme starten](03_aufnahme_start.png)

4. **Ebene > Kopien sichtbarer Ebenen kombinieren** ausführen.

   ![Sichtbare Ebenen kombinieren](04_kopien_sichtbarer_ebenen_kombinieren.png)

5. Mit `Strg+C` die entstandene Ebene kopieren.

   ![Kopieren](05_kopieren.png)

6. Die temporäre zusammengeführte Ebene löschen.

   ![Temporäre Ebene löschen](06_temporaere_ebene_loeschen.png)

7. Die Aufnahme stoppen und die Action sinnvoll benennen.

   ![Fertige Action](07_action_fertig.png)

Das beiliegende `sample-artwork-layered.clip` ist das mehrschichtige Beispieldokument aus den Screenshots.
